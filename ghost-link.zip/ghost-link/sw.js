const CACHE_NAME = 'ghost-link-v1';
const OFFLINE_URL = './offline.html';

const STATIC_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './offline.html',
  './icons/icon-192.svg',
  './icons/icon-512.svg',
  'https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=VT323&display=swap',
  'https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js'
];

/* ── INSTALL ── cache all static assets */
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      await cache.addAll(STATIC_ASSETS.filter(url => !url.startsWith('https://')));
      try {
        await cache.addAll(STATIC_ASSETS.filter(url => url.startsWith('https://')));
      } catch (_) {}
    })
  );
  self.skipWaiting();
});

/* ── ACTIVATE ── clean up old caches */
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

/* ── FETCH ── cache-first, fall back to network, then offline page */
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  const url = new URL(event.request.url);

  if (url.origin === location.origin || url.hostname.includes('fonts.googleapis') || url.hostname.includes('unpkg.com')) {
    event.respondWith(
      caches.match(event.request).then((cached) => {
        if (cached) return cached;

        return fetch(event.request.clone()).then((response) => {
          if (!response || response.status !== 200 || response.type === 'opaque') {
            return response;
          }
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          return response;
        }).catch(() => {
          if (event.request.mode === 'navigate') {
            return caches.match(OFFLINE_URL);
          }
        });
      })
    );
  }
});

/* ── BACKGROUND SYNC ── queue outbound messages when offline */
const MSG_QUEUE_STORE = 'ghost-link-msg-queue';

self.addEventListener('sync', (event) => {
  if (event.tag === 'ghost-link-msg-sync') {
    event.waitUntil(flushMessageQueue());
  }
});

async function flushMessageQueue() {
  const db = await openMsgDB();
  const tx = db.transaction(MSG_QUEUE_STORE, 'readwrite');
  const store = tx.objectStore(MSG_QUEUE_STORE);
  const all = await idbAll(store);

  for (const item of all) {
    try {
      const clients = await self.clients.matchAll({ type: 'window' });
      for (const client of clients) {
        client.postMessage({ type: 'flush-queued-msg', payload: item });
      }
      await idbDelete(store, item.id);
    } catch (_) {}
  }
  await tx.done;
}

function openMsgDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('ghost-link-db', 1);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(MSG_QUEUE_STORE)) {
        db.createObjectStore(MSG_QUEUE_STORE, { keyPath: 'id' });
      }
    };
    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror = (e) => reject(e.target.error);
  });
}

function idbAll(store) {
  return new Promise((resolve, reject) => {
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function idbDelete(store, id) {
  return new Promise((resolve, reject) => {
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

/* ── PERIODIC BACKGROUND SYNC ── keep connection alive signal */
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'ghost-link-keepalive') {
    event.waitUntil(handlePeriodicSync());
  }
});

async function handlePeriodicSync() {
  const clients = await self.clients.matchAll({ type: 'window' });
  for (const client of clients) {
    client.postMessage({ type: 'periodic-sync-ping' });
  }
}

/* ── PUSH NOTIFICATIONS ── receive push and show notification */
self.addEventListener('push', (event) => {
  let data = { title: 'Ghost Link', body: 'New message in your tunnel', icon: './icons/icon-192.svg', badge: './icons/icon-96.svg' };

  if (event.data) {
    try { data = { ...data, ...event.data.json() }; } catch (_) {}
  }

  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: data.icon,
      badge: data.badge,
      vibrate: [200, 100, 200],
      tag: 'ghost-link-msg',
      renotify: true,
      requireInteraction: false,
      data: { url: data.url || './' },
      actions: [
        { action: 'open', title: 'Open Tunnel' },
        { action: 'dismiss', title: 'Dismiss' }
      ]
    })
  );
});

/* ── NOTIFICATION CLICK ── focus or open the app */
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'dismiss') return;

  const targetUrl = event.notification.data?.url || './';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
      for (const client of clients) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});

/* ── MESSAGE from page ── handle requests from the main thread */
self.addEventListener('message', (event) => {
  if (event.data?.type === 'skip-waiting') {
    self.skipWaiting();
  }
  if (event.data?.type === 'queue-msg') {
    openMsgDB().then((db) => {
      const tx = db.transaction(MSG_QUEUE_STORE, 'readwrite');
      tx.objectStore(MSG_QUEUE_STORE).put(event.data.payload);
    });
  }
});
